#include<stdio.h>//头文件
int main()//主函数
{
  char character_Big,character_Small;//定义字符变量
  printf("请输入字母：");
  scanf("%c",&character_Big);//键盘输入字符
  character_Small=(character_Big>='A'&&character_Big<='Z')?(character_Big+32):character_Big;
  printf("%c\n",character_Small);//输出
  return 0;//函数返回值为0
}


//什么是三目运算符？
//
//b?x:y;
//
//先计算条件b，然后进行判断。如果b的值为true，计算x的值，运算结果为x的值；否则，计算y的值，运算结果为y的值，条件表达式相当于一个不带关键字if的if语句，用它处理简单的选择结构可使程序简洁。
