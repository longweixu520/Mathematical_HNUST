#include<stdio.h>//头文件
 int main() //主函数
 {
   float f_Degree,centigrade; //定义浮点型变量
   f_Degree=98.0;//初始化华氏度变量
   centigrade=(5/9.0)*(f_Degree-32);//注意此处应该是5.0
   printf("华氏度98的摄氏度为：%f\n",centigrade);//输出结果
   return 0;//函数返回值为0
 }


//有一点需要格外注意，就是这行代码：
//
//centigrade=(5/9.0)*(f_Degree-32);
//
//如果写成：
//
//centigrade=(5/9)*(f_Degree-32);
//
//那么就会出现逻辑性错误：
//
//华氏度98的摄氏度为：0.000000